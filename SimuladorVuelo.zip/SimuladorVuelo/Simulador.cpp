#define PROYECTO "Daniil Antsyferov, Simulador del vuelo"

#include <iostream>		
#include <sstream>
#include <Utilidades.h>

using namespace std;

// terreno es infinito
// FOV = RENDER_DIST / 2
// bajar valor de RESOLUCION para mas FPS si es necesario
const int RENDER_DIST = 100; 
//const int EXTENSION = 1000;
const int RESOLUCION = 100; //150 //200
const int FOV = 50;

//giro de camara en gradus, respetando las restricciones
static float giroCamX = 0, giroCamY = 0;

//velocidad por defecto
static float velocidad = 2;

// distancia recorrida coherente con tiempo
static float distRecorridaX = 0;
static float distRecorridaY = 0;

// angulo de direccion 0-360
static float dirAngle = 225;

static bool AUTO_PILOT = false;
static float desiredElevation = 10; // elevacion que va a mantener el autopiloto

static bool NIGHT_MODE = false;
static bool L2on = false;

static bool CABIN_MODE = true;

//dragging counters
int xanterior, yanterior;

GLuint terreno, agua, nieve, cabina, speedometer, elevationmeter, compass;

//posicion actual
float X, Y, Z;

void init()
{
	cout << "Iniciando " << PROYECTO << endl;
	cout << "GL version " << glGetString(GL_VERSION) << endl;

	glGenTextures(1, &terreno);
	glBindTexture(GL_TEXTURE_2D, terreno);
	loadImageFile((char*)"forest.png");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

	glGenTextures(1, &agua);
	glBindTexture(GL_TEXTURE_2D, agua);
	loadImageFile((char*)"agua.png");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

	glGenTextures(1, &nieve);
	glBindTexture(GL_TEXTURE_2D, nieve);
	loadImageFile((char*)"snow.png");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

	glGenTextures(1, &cabina);
	glBindTexture(GL_TEXTURE_2D, cabina);
	loadImageFile((char*)"cockpit.png");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

	glGenTextures(1, &speedometer);
	glBindTexture(GL_TEXTURE_2D, speedometer);
	loadImageFile((char*)"meter4.png");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

	glGenTextures(1, &elevationmeter);
	glBindTexture(GL_TEXTURE_2D, elevationmeter);
	loadImageFile((char*)"meter5.png");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

	glGenTextures(1, &compass);
	glBindTexture(GL_TEXTURE_2D, compass);
	loadImageFile((char*)"compass.png");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

	GLfloat Al[] = { 0.2,0.2,0.2,1.0 };
	GLfloat Dl[] = { 1.0,1.0,0.5,1.0 };
	GLfloat Sl[] = { 1.0,1.0,0.5,1.0 }; 

	glLightfv(GL_LIGHT1, GL_AMBIENT, Al); 
	glLightfv(GL_LIGHT1, GL_DIFFUSE, Dl);
	glLightfv(GL_LIGHT1, GL_SPECULAR, Sl);
	glLightf(GL_LIGHT1, GL_SPOT_CUTOFF, 30.0);
	glLightf(GL_LIGHT1, GL_SPOT_EXPONENT, 5.0);

	glLightfv(GL_LIGHT2, GL_AMBIENT, Al); 
	glLightfv(GL_LIGHT2, GL_DIFFUSE, Dl);
	glLightfv(GL_LIGHT2, GL_SPECULAR, Sl);
	glLightf(GL_LIGHT2, GL_SPOT_CUTOFF, 10.0);
	glLightf(GL_LIGHT2, GL_SPOT_EXPONENT, 5.0);

	glEnable(GL_COLOR_MATERIAL);
	glEnable(GL_NORMALIZE);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	/*glCullFace(GL_FRONT_AND_BACK);
	glEnable(GL_CULL_FACE);*/

	glEnable(GL_FOG);
	glFogfv(GL_FOG_COLOR, BLANCO);
	glFogf(GL_FOG_DENSITY, 0.3);
	glFogf(GL_FOG_START, 0.0);
	glFogf(GL_FOG_END, RENDER_DIST * 0.8 );
	glFogi(GL_FOG_MODE, GL_LINEAR);

	X = 30;
	Y = 30;
	Z = 10;
}

float elevacion(float x, float y)
{
	float res = 3 * (sin(0.3 * x) + cos(0.3 * y));
	if (res < -2) res = -2;
	return res;
}

void FPS()
{
	// Cuenta los fotogramas por segundo y los muestra en
	// la barra de titulo de la ventana

	static int antes = glutGet(GLUT_ELAPSED_TIME);
	static int fotogramas = 0;
	int ahora, tiempoTranscurrido;

	fotogramas++;

	ahora = glutGet(GLUT_ELAPSED_TIME);
	tiempoTranscurrido = (ahora - antes) / 1000;

	// si ha transcurrido mas de un segundo, muestro los FPS y reinicio
	// la cuenta y el reloj
	if (tiempoTranscurrido >= 1) {
		stringstream titulo;
		titulo << PROYECTO << ", FPS= " << fotogramas;
		glutSetWindowTitle(titulo.str().c_str());
		// reinicio
		antes = ahora;
		fotogramas = 0;
	}
}


void display()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	

	//luz de noche / dia
	if (NIGHT_MODE) {
		const GLfloat A[] = { 0.2,0.2,0.2,1 };
		const GLfloat FC[] = { 0, 0, 0.2f, 1.0f };
		glLightModelfv(GL_LIGHT_MODEL_AMBIENT, A);
		glClearColor(0, 0, 0.2f, 1.0f);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		glFogfv(GL_FOG_COLOR, FC);
	} else {
		const GLfloat A[] = { 1,1,0.8,1 };
		const GLfloat FC[] = { 0.5f, 0.7f, 1.0f, 1.0f };
		glLightModelfv(GL_LIGHT_MODEL_AMBIENT, A);
		glClearColor(0.5f, 0.7f, 1.0f, 1.0f);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
		glFogfv(GL_FOG_COLOR, FC);
	}

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	//Luz movil
	GLfloat posicionMovil[] = { 0,0,0,1 };
	glLightfv(GL_LIGHT2, GL_POSITION, posicionMovil); 
	GLfloat dirMovil[] = { 0.0, 0.0, -1.0 }; 
	glLightfv(GL_LIGHT2, GL_SPOT_DIRECTION, dirMovil);

	X += distRecorridaX;
	Y += distRecorridaY;

	if (AUTO_PILOT) {
		Z = elevacion(X+FOV, Y+FOV) + desiredElevation;
	}

	float camX = giroCamX + dirAngle;
	//cout << "\ngiroX: " << camX;

	float incX = (cos(camX * PI / 180) * FOV);
	float incY = (sin(camX * PI / 180) * FOV);
	float incZ = (tan(giroCamY * PI / 180) * FOV);


	gluLookAt(X,Y,Z, X + incX,Y + incY, Z + incZ, 0, 0, 1);

	// luz de faro
	GLfloat posicionFija[] = { X,Y,Z,1 };
	glLightfv(GL_LIGHT1, GL_POSITION, posicionFija); 
	GLfloat dirFija[] = { 0, 0, -1.0 }; 
	glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, dirFija);

	GLfloat inc = (float)RENDER_DIST / (float)RESOLUCION;

	GLfloat x0 = X + inc, x1 = X, x2 = X + inc, x3 = X;
	GLfloat y0 = Y + inc, y1 = Y + inc, y2 = Y, y3 = Y;
	
	
	glPushMatrix();
	glTranslatef(-FOV, -FOV, 0);

	for (int i = 0; i < RESOLUCION; i++) {
		for (int j = 0; j < RESOLUCION; j++) {


			GLfloat incX = inc * i, incY = inc * j;

			float z0 = elevacion(x0 + incX, y0 + incY);
			float z1 = elevacion(x1 + incX, y1 + incY);
			float z2 = elevacion(x2 + incX, y2 + incY);
			float z3 = elevacion(x3 + incX, y3 + incY);

			if (z0 <= -2 && z1 <= -2 && z2 <= -2 && z3 <= -2) {
				glColor3f(0.5f, 0.7f, 1.0f);
				glBindTexture(GL_TEXTURE_2D, agua);
			} else if (z0 >= 3 && z1 >= 3 && z2 >= 3 && z3 >= 3) {
				glColor3f(1, 1, 1);
				glBindTexture(GL_TEXTURE_2D, nieve);
			} else {
				glColor3f(0, 1, 0);
				glBindTexture(GL_TEXTURE_2D, terreno);
			}

			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);

			glBegin(GL_POLYGON);

			glTexCoord2f(2, 2);
			glVertex3f(x0 + incX, y0 + incY, z0);
			glTexCoord2f(0, 2);
			glVertex3f(x2 + incX, y2 + incY, z2);
			glTexCoord2f(2, 0);
			glVertex3f(x3 + incX, y3 + incY, z3);
			glTexCoord2f(0, 0);
			glVertex3f(x1 + incX, y1 + incY, z1);

			glEnd();
		}
	}

	if (CABIN_MODE) {

		glMatrixMode(GL_PROJECTION);
		glPushMatrix();
		glLoadIdentity();
		glOrtho(-1, 1, -1, 1, -1, 1);
		glMatrixMode(GL_MODELVIEW);
		glPushMatrix();
		glLoadIdentity();
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
		glDisable(GL_LIGHTING);

		glPushMatrix();
		glTranslatef(-0.37, -0.5, 0);

		glPushMatrix();
		glTranslatef(0.1, 0.1, 0);
		glRotatef(180, 0, 0, 1);
		glRotatef(-270 * (velocidad+10) / 20, 0, 0, 1);
		glDisable(GL_TEXTURE_2D);
		glColor3f(1, 0, 0);
		glBegin(GL_POLYGON);

		glVertex3f(0.07, 0.07, 0);
		glVertex3f(0, 0.01, 0);
		glVertex3f(0.0, 0.0, 0);
		glVertex3f(0.01, 0, 0);

		glEnd();
		glEnable(GL_TEXTURE_2D);
		glPopMatrix();

		glBindTexture(GL_TEXTURE_2D, speedometer);
		static  GLfloat v0s[] = { 0,0,0 };
		static  GLfloat v1s[] = { 0.2,0,0 };
		static  GLfloat v2s[] = { 0.2,0.2,0 };
		static  GLfloat v3s[] = { 0,0.2,0 };
		quadtex(v0s, v1s, v2s, v3s, 0, 1, 0, 1);

		glPopMatrix();


		glPushMatrix();
		glTranslatef(-0.37, -0.7, 0);

		glPushMatrix();
		glTranslatef(0.1, 0.1, 0);
		glRotatef(180, 0, 0, 1);
		glRotatef(-270 * (Z - elevacion(X + FOV, Y + FOV)) / 50, 0, 0, 1);
		glDisable(GL_TEXTURE_2D);
		glColor3f(1, 0, 0);
		glBegin(GL_POLYGON);

		glVertex3f(0.07, 0.07, 0);
		glVertex3f(0, 0.01, 0);
		glVertex3f(0.0, 0.0, 0);
		glVertex3f(0.01, 0, 0);

		glEnd();
		glEnable(GL_TEXTURE_2D);
		glPopMatrix();

		glBindTexture(GL_TEXTURE_2D, elevationmeter);
		static  GLfloat v0e[] = { 0,0,0 };
		static  GLfloat v1e[] = { 0.2,0,0 };
		static  GLfloat v2e[] = { 0.2,0.2,0 };
		static  GLfloat v3e[] = { 0,0.2,0 };
		quadtex(v0e, v1e, v2e, v3e, 0, 1, 0, 1);

		glPopMatrix();

		glPushMatrix();
		glTranslatef(0, -0.5, 0);
		glRotatef(dirAngle, 0, 0, 1);
		glTranslatef(-0.09, -0.09, 0);

		glBindTexture(GL_TEXTURE_2D, compass);
		static  GLfloat v0c[] = { 0,0,0 };
		static  GLfloat v1c[] = { 0.18,0,0 };
		static  GLfloat v2c[] = { 0.18,0.18,0 };
		static  GLfloat v3c[] = { 0,0.18,0 };
		quadtex(v0c, v1c, v2c, v3c, 0, 1, 0, 1);
		
		glPopMatrix();

		

		

		glBindTexture(GL_TEXTURE_2D, cabina);
		static  GLfloat v0[] = { -1,-1,0 };
		static  GLfloat v1[] = { 1,-1,0 };
		static  GLfloat v2[] = { 1,1,0 };
		static  GLfloat v3[] = { -1,1,0 };
		quadtex(v0, v1, v2, v3, 0, 1, 0, 1);

		glPushMatrix();
		glTranslatef(-0.005, -0.4, 0);
		char textN[] = "N";
		texto(0, 0, textN, ROJO, GLUT_BITMAP_HELVETICA_18, true);
		glPopMatrix();

		glPopMatrix();
		glMatrixMode(GL_PROJECTION);
		glPopMatrix();
		glEnable(GL_LIGHTING);

	}

	char textHUD[] = "HUD: Piloto Daniil Antsyferov";
	texto(10, 120, textHUD, VERDE, GLUT_BITMAP_HELVETICA_18, false);

	char textSPEED[50] = "Speed: ";
	std::string speed = std::to_string(velocidad).substr(0, 4);
	strcat_s(textSPEED, speed.c_str());
	strcat_s(textSPEED, " m/s");
	texto(10, 100, textSPEED, VERDE, GLUT_BITMAP_HELVETICA_18, false);

	char textHEIGHT[50] = "Height: ";
	std::string height = std::to_string(Z).substr(0, 4);
	strcat_s(textHEIGHT, height.c_str());
	strcat_s(textHEIGHT, " m");
	texto(10, 80, textHEIGHT, VERDE, GLUT_BITMAP_HELVETICA_18, false);

	char textELEVATION[50] = "Elevation: ";
	std::string elevation = std::to_string(Z - elevacion(X + FOV, Y + FOV)).substr(0, 4);
	strcat_s(textELEVATION, elevation.c_str());
	strcat_s(textELEVATION, " m");
	texto(10, 60, textELEVATION, VERDE, GLUT_BITMAP_HELVETICA_18, false);

	char textDIRECTION[50] = "Direction: ";
	std::string direction = std::to_string(dirAngle).substr(0, 4);
	strcat_s(textDIRECTION, direction.c_str());
	strcat_s(textDIRECTION, " (0-360)");
	texto(10, 40, textDIRECTION, VERDE, GLUT_BITMAP_HELVETICA_18, false);


	char textAUTOPILOT[50] = "Autopilot: ";
	if (AUTO_PILOT) {
		strcat_s(textAUTOPILOT, " ON");
		texto(10, 20, textAUTOPILOT, VERDE, GLUT_BITMAP_HELVETICA_18, false);
	} else {
		strcat_s(textAUTOPILOT, " OFF");
		texto(10, 20, textAUTOPILOT, ROJO, GLUT_BITMAP_HELVETICA_18, false);
	}
	

	glPopMatrix();
	glutSwapBuffers();

	FPS();
}

void reshape(GLint w, GLint h)
{
	float relacionAspecto = float(w) / h;
	glViewport(0, 0, w, h);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	gluPerspective(60, relacionAspecto, 1, 100);
}

void onSpecialInput(int key, int x, int y)
{
	switch (key)
	{
	case GLUT_KEY_UP:
		if (Z < 50)
			Z += 1;
		break;
	case GLUT_KEY_DOWN:
		if (Z - 3 > elevacion(X + FOV, Y + FOV))
			Z -= 1;
		break;
	case GLUT_KEY_LEFT:
		dirAngle -= 5;
		dirAngle = (int)dirAngle % 360;
		break;
	case GLUT_KEY_RIGHT:
		dirAngle +=  5;
		dirAngle = (int)dirAngle % 360;
		break;
	}

	glutPostRedisplay();
}

void onDrag(int x, int y){
	if (xanterior != 0) {

		giroCamX += (x - xanterior) * 0.2;
		if (giroCamX > 89)
			giroCamX = 89;

		if (giroCamX < -89)
			giroCamX = -89;

	}

	if (yanterior != 0) {
		giroCamY -= (y - yanterior) * 0.2;

		if (giroCamY > 45)
			giroCamY = 45;

		if (giroCamY < -89)
			giroCamY = -89;
	}

	xanterior = x;
	yanterior = y;

	glutPostRedisplay();
}

void onKey(unsigned char tecla, int x, int y)
{
	switch (tecla) {
	case 'a':
	case 'A':
		velocidad += 1;
		if (velocidad > 10) velocidad = 10;
		break;
	case 'z':
	case 'Z':
		velocidad -= 1;
		if (velocidad < -10) velocidad = -10;
		break;
	case 'q':
	case 'Q':
		AUTO_PILOT = !AUTO_PILOT;
		break;
	case 'f':
	case 'F':
		NIGHT_MODE = !NIGHT_MODE;
		L2on = NIGHT_MODE;
		if (NIGHT_MODE) {
			glEnable(GL_LIGHT1);
			glEnable(GL_LIGHT2);
		} else {
			glDisable(GL_LIGHT1);
			glDisable(GL_LIGHT2);
		}
		break;
	case 'l':
	case 'L':
		if (NIGHT_MODE) {
			L2on = !L2on;
			if (L2on) glEnable(GL_LIGHT2); else glDisable(GL_LIGHT2);
		}
		break;
	case 'c':
	case 'C':
		CABIN_MODE = !CABIN_MODE;
		break;
	case 27:
		exit(0);
	}

	glutPostRedisplay();
}

void onMouse(int button, int state, int x, int y) {
	if (button == GLUT_LEFT_BUTTON && state == GLUT_UP) {
		xanterior = 0;
		yanterior = 0;
	}
}

void onIdle() 
{
	static int antes = glutGet(GLUT_ELAPSED_TIME);
	int ahora = glutGet(GLUT_ELAPSED_TIME);
	//cout << "\nDir angle: " << dirAngle;

	float dist = velocidad * (ahora - antes) / 1000;
	float rad = dirAngle * PI / 180;

	distRecorridaX = dist * cos(rad);
	distRecorridaY = dist * sin(rad);

	antes = ahora;
	glutIdleFunc(onIdle);
	glutPostRedisplay();

}


int main(int argc, char** argv)
{
	FreeImage_Initialise();
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(1500, 1000);
	glutCreateWindow(PROYECTO);
	init();

	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutMotionFunc(onDrag);
	glutSpecialFunc(onSpecialInput);
	glutIdleFunc(onIdle);
	glutKeyboardFunc(onKey);
	glutMouseFunc(onMouse);

	glutMainLoop();
	FreeImage_DeInitialise();
}